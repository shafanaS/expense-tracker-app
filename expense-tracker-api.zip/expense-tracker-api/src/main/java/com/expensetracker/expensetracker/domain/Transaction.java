package com.expensetracker.expensetracker.domain;

public class Transaction {

    private String description;
    private Double amount;
    private Integer categoryId;
    private String month;
    private Boolean isIncome;

    public Transaction(String description, Double amount, Integer categoryId, String month, Boolean isIncome) {
        this.description = description;
        this.amount = amount;
        this.categoryId = categoryId;
        this.month=month;
        this.isIncome = isIncome;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }


    public Integer getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public String getmonth() { return month;}

    public void setmonth(Integer month) {this.month = month;}

    public Boolean getisIncome() {
        return isIncome;
    }

    public void setisIncome(Integer isIncome) {
        this.isIncome = isIncome;
    }
}
