package com.expensetracker.expensetracker.repositories;

import com.expensetracker.expensetracker.domain.Transaction;
import com.expensetracker.expensetracker.exceptions.EtBadRequestException;
import com.expensetracker.expensetracker.exceptions.EtResourceNotFoundException;

import java.util.List;

public interface TransactionRepository {


    Integer create(Integer description,Double amount,Integer categoryId,String month, Boolean isIncome) throws EtBadRequestException;

    void removeById(Integer transactionId) throws EtResourceNotFoundException;

}
